package com.portfolio.RAG;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RagApplicationTests {

	@Test
	void contextLoads() {
	}

}
